/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainapp;

/**
 *
 * @author AMEIR IHTISHAM
 */
import studentdata.Student;
import java.util.ArrayList;
import java.util.Arrays;
public class MainApp {
    public static void main(String[] args){
        String filename = "students.txt";
        
        //cipta data
        //cipta data satu per satu
           ArrayList<Student> students = new ArrayList<>();
           students.add(new Student("Nazrie","S001",93.0));
           students.add(new Student("Rafael","S002",85.5));
           students.add(new Student("Amani","S005",77.6));
        //new Student sbb itu nama constructor 
        
        //cipta data
        //versi kurangkan kod
//        students.addAll(Arrays.asList(
//                new Student("Nazrie","S001",93.0),
//                new Student("Rafael","S002",85.5),
//                new Student("Amani","S005",77.6)
//        ));
        
        //save ke fail
        //constructor@nama fail htr ke method
        Student.saveToFile(students, filename);
        
        
        //baca dan papar produk dari fail
        System.out.println("\nReading from file.....");
        // slash n untuk jarak
        ArrayList<Student> studentData = Student.readFromFile(filename);
        
        for(Student s : studentData){
            System.out.println(s);
        }
    }
}
