/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentdata;

/**
 *
 * @author AMEIR IHTISHAM
 */
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class Student {
    //variable dan jenis data
    private String name,studentID;
    double marks;
    
    //constructor
    public Student(String name,String studentID,double marks){
        this.name = name;
        this.studentID = studentID;
        this.marks = marks;
    }
    
    //getter
    public String getName(){
        return name;
    }
    public String getStudentID(){
        return studentID;
    }
    public double getMarks(){
        return marks;
    }
    
    //setter
    public void setName(String name){
        this.name = name;
    }
    public void setStudentID(String studentID){
        this.studentID = studentID;
    }
    public void setMarks(double marks){
        if(marks > 00.0){
            this.marks = marks;
        }
    }
    
    //tulis data
    @Override
    public String toString(){
        return "Name: " + name + ",ID:" + studentID + ",Marks:" + marks;
    }
    
    //simpan data ke fail
    public static void saveToFile(ArrayList<Student> students,String filename){
        //yg students tu nama fail yang kita nak create
        try(FileWriter writer = new FileWriter(filename)){
            for(Student s : students){
                //Student nama fail java
                //s objek
                //students nama fail yang nak create
                writer.write(s.getName() + "," + s.getStudentID() + "," + s.getMarks() + "\n");
//                System.out.println("Data berjaya disimpan ke fail: " + filename);
//                //klu letak dalam ni setiap kali data disimpan dia akan htr message
            }
            System.out.println("Data berjaya disimpan ke fail: " + filename);
            //klu letak luar dia akan tulis sekali ja
        }catch(IOException e){
            System.out.println("Data gagal disimpan ke fail " + e.getMessage());
        }
    }
    
    //baca data dari fail
    public static ArrayList<Student> readFromFile (String filename){
        ArrayList<Student> students = new ArrayList<>();
        try(Scanner scanner = new Scanner(new File(filename))){
            while(scanner.hasNextLine()){
                String[] student_data = scanner.nextLine().split(",");
                if(student_data.length == 3 ){
                    students.add(new Student(student_data[0],student_data[1],Double.parseDouble(student_data[2])));
                    //New Student menandakan fail baharu
                    //student_data - objek yang mengambil data
                    //[0],[1],[2] menandakan tempat dalam array
                }
            }
        }catch(FileNotFoundException e){
            System.out.println("Ralat:Fail tidak dijumpai(" + filename + ")");
        }catch(IOException e){
            System.out.println("Data gagal dibaca " + e.getMessage());
        }
        return students;
        //kembalikan fail
    }
}
